package br.edu.unoesc.ExceptionDao;

public class MinhaExceptionDAO extends Exception{
	
	private static final long serialVersionUID = 6527906551932778819L;

	public MinhaExceptionDAO(String msg) {
       super(msg);

}}

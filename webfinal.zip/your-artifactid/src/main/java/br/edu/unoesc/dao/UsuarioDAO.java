package br.edu.unoesc.dao;

import javax.enterprise.context.RequestScoped;

import br.edu.unoesc.model.Usuario;

@RequestScoped
public class UsuarioDAO extends GenericDAO<Usuario>{

	
	
}

package br.edu.unoesc.model;

public interface MeuModelo {
	
	Long getCodigo();

}
